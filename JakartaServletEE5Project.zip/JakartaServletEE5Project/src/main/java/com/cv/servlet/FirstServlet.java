package com.cv.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import org.apache.log4j.Logger;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * @author Chandra
 *
 */

/**
 * Servlet implementation class FirstServlet
 */

public class FirstServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private static final Logger LOGGER = Logger.getLogger(FirstServlet.class);

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public FirstServlet() {
		super();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		LOGGER.info("Entered into doGet(HttpServletRequest ,HttpServletResponse ) of FirstServlet class... ");
		// setting the MIME type.
		response.setContentType("text/html");

		// getting the PrintWriter object
		PrintWriter out = response.getWriter();

		String name = request.getParameter("requestParam1");
		out.print("Hello : : " + name);
		
		
		RequestDispatcher rd = getServletContext().getRequestDispatcher("/second.jsp");
		rd.include(request, response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		LOGGER.info("Entered into doPost(HttpServletRequest ,HttpServletResponse ) of FirstServlet class... ");
		doGet(request, response);
	}

}
