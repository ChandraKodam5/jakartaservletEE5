package com.cv.servlet.urlrewrite;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

/**
 * Servlet implementation class LoginServlet
 */

public class LoginServlet extends HttpServlet {

	private static final Logger LOGGER = Logger.getLogger(LoginServlet.class);
	private final String userID = "chandra";
	private final String password = "123cv";

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		LOGGER.info("Entered into doPost(--) of LoginServlet class... ");
		// get request parameters for userID and password
		String user = request.getParameter("user");
		String pwd = request.getParameter("pwd");
		if (userID.equals(user) && password.equals(pwd)) {
			LOGGER.info("Entered username : " + user + " AND password : " + pwd + " are correct..." );
			HttpSession session = request.getSession();
			session.setAttribute("user", "cv");
			// setting session to expiry in 30 mins
			session.setMaxInactiveInterval(30 * 60);
			Cookie userName = new Cookie("user", user);
			response.addCookie(userName);		
			// Get the encoded URL string
			String encodedURL = response.encodeURL("success.jsp");
			LOGGER.info("Control Redirecting to success.jsp...");
			response.sendRedirect(encodedURL);
		} else {
			LOGGER.info("Entered username : " + user + " AND password : " + pwd + " are INVALID..." );
			RequestDispatcher rd = getServletContext().getRequestDispatcher("/login.html");
			PrintWriter out = response.getWriter();
			out.println(
					"<center><font color=red>Either user name or password is wrong. Please look at logs...</font></center>");
			LOGGER.info("Please enter username : chandra & password: 123cv");
			rd.include(request, response);
		}

	}

}